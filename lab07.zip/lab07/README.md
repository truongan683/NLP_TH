# LAB 07 — Transformer Architecture

Bài làm theo các yêu cầu trong w7.pdf, gồm lý thuyết, phép tính, core tự ghép, mười cấu hình thực nghiệm đã chạy, notebook để train lại, ứng dụng sentiment và phân tích lỗi. Toàn bộ kết quả là số đo CPU thực, không phải số minh họa.

## Mở bài làm

- Mở `transformer_classification.ipynb` để xem tuần tự toàn bộ bài.
- `calculations.md`: các phép tính, shape và giải thích thành phần.
- `prediction.md`: dự đoán ghi trước khi train; `prediction_verification.md`: đối chiếu riêng.
- `experiment_analysis.md`: bảng số liệu và nhận xét sáu nhóm thí nghiệm.
- `error_analysis.md`: ba dự đoán đúng, ba dự đoán sai trên test, quan sát attention.
- `reflection.md`: progression LAB 01–07, giới hạn, câu hỏi kiểm tra cá nhân và liên hệ BERT.

## Chạy lại

Dùng Python có các packages trong requirements.txt (đã chạy bằng Python 3.14.6, PyTorch CPU). Từ thư mục repository:

```powershell
python -m pip install -r lab07/requirements.txt
python lab07/run_experiments.py --epochs 4
python lab07/build_reports.py
python lab07/build_notebook.py
python lab07/predict.py "I really enjoyed this movie."
```

Notebook hiện chạy training khi chọn Run All, tự chọn CUDA/CPU. build_notebook.py chỉ tạo notebook với outputs trống, không tự train.

## Dữ liệu và thiết kế

Nguồn: `../datasets/imdb/IMDB Dataset.csv`. Chọn 2.000 mẫu đầu mỗi nhãn, shuffle seed 42, train/validation/test=2.800/400/800. `split_manifest.csv` ghi dòng nguồn 0-based và nhãn từng mẫu, `data_audit.json` ghi hai training reviews bị thay để loại exact duplicate với held-out. Giữ nguyên validation/test. Vocab tối đa 7.500 từ thường + PAD/UNK/CLS, fit chỉ trên train. Lowercase, bỏ HTML br, regex letters/digits, split whitespace. Không dùng pretrained weights.

Không tìm thấy LAB 05; cách chọn mẫu và test dựa trên notebook LAB 06 ở Git HEAD. Tách validation từ phần train cũ. Đây là split ngẫu nhiên của CSV, không phải official IMDb benchmark. Exact duplicate audit không phát hiện gần trùng hoặc mọi loại leakage. Không đưa kết quả hiện tại thành tuyên bố benchmark chuẩn.

Cùng d_model=128, d_ff=256, 1 encoder block, dropout 0.1, batch=32, Adam lr=0.001, gradient clip=1, epochs=4, seed=42. Checkpoint chọn minimum validation loss. Precision/Recall/F1 là macro. LSTM hidden=128 dùng packed sequences và last hidden. Baseline Transformer=4 heads, length=64, masked mean pooling; baseline được định trước.

## Kết quả chính

| model | max_length | parameters | training_seconds | accuracy | f1 |
| --- | --- | --- | --- | --- | --- |
| LSTM | 64 | 1092738 | 16.6595 | 0.5275 | 0.5230 |
| Transformer | 64 | 1093122 | 13.2761 | 0.6562 | 0.6493 |
| Transformer | 256 | 1093122 | 82.9957 | 0.7712 | 0.7712 |

Các ablation: heads=1/2/4/8; length=32/64/128/256; mean/CLS-style; có/không PE. Baseline dùng lại giữa các bảng để không train trùng cấu hình. Chỉ một seed/bốn epoch; cần nhiều seed và tuning trên validation để kết luận mạnh hơn. Memory scores trong results.csv là ước tính B×h×T²×4 bytes, không phải peak RAM. Training time loại validation/test, còn fit_wall_seconds gồm train và validation/chọn checkpoint. Thời gian không bao gồm data preparation.

## Thành phần thực thi và kiểm tra

`transformer_block.py`: tự chiếu Q/K/V, chia head, scale, key padding mask, softmax, nối heads, WO, residual, post-LayerNorm và FFN. Không dùng TransformerEncoderLayer hoặc MultiheadAttention cho core. PyTorch MultiheadAttention chỉ dùng làm reference trong checks().

`shape_checks.json` ghi kiểm tra B=8,T=100,d=128,h=4; chuẩn hóa attention; padding invariance; so với reference attention; finite gradients. `permutation_results.json` lưu token vectors của thí nghiệm hoán vị với embedding nhỏ tự chọn. Hai cặp câu dùng cùng bộ ba vector, không dùng embedding từ classifier.

`results.csv`, `history.json`, `test_predictions.csv`, `application_predictions.csv`, `head_diversity.json`, `error_examples.json`, `config.json` lưu số liệu thô. `transformer_model.pt` và `vocab.json` phục vụ inference. `positional_encoding.png`, `attention_heads.png`, `learning_curves.png`, `confusion_matrix.png` là bốn hình theo đề. Notebook chạy lại các thí nghiệm và lưu kết quả ra file.

Đề không cho giá trị X/WQ/WK/WV (mục 6), W2/b2 (mục 14); calculations.md giải tổng quát và ghi rõ ví dụ tự chọn. Peer assessment và phần vấn đáp cần người học/reviewer tự thực hiện; không tự nhận đã có đánh giá từ người khác.


## Notebook huấn luyện lại (cập nhật)

Notebook hiện chỉ chứa code chạy Experiment 1–6, đã xóa outputs và các lệnh hiển thị bảng/hình. Chọn Run All để train lại; DEVICE='auto' tự chọn CUDA nếu khả dụng, hoặc đặt DEVICE='cuda' để bắt buộc GPU. Sửa DATASET_PATH và EPOCHS trong cell cấu hình. Kết quả mới lưu trong training_output/; hình vẫn được lưu ra PNG, không hiển thị trong notebook. Chỉ log tiến độ training xuất hiện khi chạy. Notebook nhúng các hàm train/evaluate nên không cần run_experiments.py; cần hai module transformer_block.py, positional_encoding.py đặt cạnh notebook và dữ liệu IMDb.

Các kết quả CSV/PNG có sẵn trong bộ bài là từ lượt chạy CPU trước. Chưa chạy lại toàn bộ bằng GPU vì máy hiện tại không có CUDA. CLI hỗ trợ: python lab07/run_experiments.py --epochs 4 --device auto.
