"""Generate reports from measured results, not from illustrative numbers."""
from pathlib import Path
import hashlib, json, platform
import pandas as pd
ROOT=Path(__file__).resolve().parent

def table(df):
    def fmt(x):
        return f'{x:.4f}' if isinstance(x,float) else str(x)
    return '| '+' | '.join(df.columns)+' |\n| '+' | '.join(['---']*len(df.columns))+' |\n'+'\n'.join('| '+' | '.join(fmt(x) for x in row)+' |' for row in df.itertuples(index=False,name=None))

def write(name,text): (ROOT/name).write_text(text,encoding='utf-8')

r=pd.read_csv(ROOT/'results.csv').set_index('experiment',drop=False)
b=r.loc['baseline']; l=r.loc['lstm']; no=r.loc['no_pe']; cls=r.loc['pool_cls']
history=json.loads((ROOT/'history.json').read_text()); diversity=json.loads((ROOT/'head_diversity.json').read_text());perm=json.loads((ROOT/'permutation_results.json').read_text())
heads=r.loc[['heads_1','heads_2','baseline','heads_8']]
lengths=r.loc[['length_32','baseline','length_128','length_256']]
analysis=f'''# Phân tích kết quả thực nghiệm

Các số dưới đây lấy trực tiếp từ results.csv. Một seed 42, bốn epochs; không có kiểm định ý nghĩa thống kê.

## 1. Positional information

Không PE: max chênh token sau căn chỉnh = {perm['without_pe']['aligned_token_max_abs_difference']:.8g}; chênh mean pooling = {perm['without_pe']['mean_pool_max_abs_difference']:.8g}. Có PE: hai đại lượng = {perm['with_pe']['aligned_token_max_abs_difference']:.6f} và {perm['with_pe']['mean_pool_max_abs_difference']:.6f}. Đây là bằng chứng thực nghiệm về symmetry và việc PE phá symmetry đó, không chỉ là phát biểu lý thuyết. File permutation_results.json lưu toàn bộ token representations.

Ablation trên classification: baseline F1={b.f1:.4f}, no-PE F1={no.f1:.4f}. Dataset sentiment có nhiều tín hiệu bag-of-words; lợi ích PE không nhất thiết hiện rõ trên subset ngắn và một seed. Không được dùng kết quả này để phủ nhận tính cần thiết của thông tin vị trí khi tác vụ đòi phân biệt thứ tự.

## 2. Number of heads

{table(heads[['heads','d_k','parameters','training_seconds','accuracy','f1']])}

Số chiều nối luôn 128 và số tham số các model Transformer bằng nhau. F1 không tăng đơn điệu theo số heads trong lượt chạy này. Các thay đổi phản ánh cách chia không gian attention, softmax riêng và đường tối ưu; không chứng minh càng nhiều heads càng tốt. Số phần tử scores tăng tuyến tính theo h dù tổng chiều embedding cố định.

## 3. Head diversity

Câu quan sát: `{diversity['sentence']}`. Entropy trung bình (thấp hơn nghĩa tập trung hơn trên cùng số token):

{table(pd.DataFrame(diversity['stats']))}

{table(pd.DataFrame([{'pair':str(v['heads']),'mean_absolute_difference':v['mean_absolute_difference']} for v in diversity['pairs']]))}

Head tập trung nhất theo entropy là head {min(diversity['stats'],key=lambda x:x['mean_entropy'])['head']}; phân tán nhất là head {max(diversity['stats'],key=lambda x:x['mean_entropy'])['head']}. Các chênh lệch giữa heads cho thấy patterns không hoàn toàn trùng nhau trên câu này. Cặp gần nhất theo mean absolute difference là {min(diversity['pairs'],key=lambda x:x['mean_absolute_difference'])['heads']}. Chỉ một câu chưa đủ kết luận head redundant trên toàn dataset; cần đo trên nhiều câu và thử ablation head. Không gán head với syntax/semantics và không coi heatmap là giải thích nhân quả.

## 4. LSTM vs Transformer

{table(r.loc[['lstm','baseline'],['model','parameters','training_seconds','accuracy','precision','recall','f1']])}

Giữ cùng dữ liệu, vocab, embedding dimension, batch, optimizer, learning rate, epochs. LSTM dùng last hidden của packed sequence; Transformer dùng mean pooling và FFN/residual/norm/dropout. Số tham số gần nhau nhưng không bằng tuyệt đối. Khác biệt gồm đường truyền dài của LSTM, tương tác trực tiếp của attention, pooling và regularization. LSTM có train loss giảm trong khi validation xấu đi, cho thấy overfitting trong cấu hình này; không đủ cơ sở suy ra LSTM luôn kém. Cần tuning độc lập trên validation và nhiều seed cho so sánh mạnh hơn.

## 5. Sequence length

{table(lengths[['max_length','tokens_retained','attention_mib','training_seconds','f1']])}

Tỷ lệ token giữ lại là micro token retention trên test, không phải phần trăm review nguyên vẹn. Cùng B=32,h=4,float32, riêng scores tăng 8→32 MiB khi length 128→256. Đây là bộ nhớ lý thuyết của một tensor; code còn tạo weights, gradients, intermediate activations. Không có phép đo peak RAM. Thời gian train cũng gồm projection/FFN/optimizer nên không nhất thiết tăng đúng bốn lần. Độ dài lớn giảm mất thông tin nhưng tăng chi phí và có thể giữ thêm noise.

## 6. Pooling

{table(r.loc[['baseline','pool_cls'],['pooling','accuracy','f1','training_seconds']])}

CLS-style thêm token <CLS> và được train từ đầu; không lấy token đầu tiên của review rồi gọi là CLS. Giữ 64 review tokens ở cả hai nên CLS có 65 positions. Cách tổng hợp ảnh hưởng kết quả; khác biệt này không phải so sánh với pretrained BERT CLS. Mean pooling nhận tín hiệu từ mọi token qua đường trực tiếp; CLS phải học thu thập thông tin qua attention.

## 7. Learning curves và đánh giá

Baseline train loss: {', '.join(f'{h["train_loss"]:.4f}' for h in history['baseline'])}. Validation loss: {', '.join(f'{h["validation_loss"]:.4f}' for h in history['baseline'])}. Checkpoint epoch {int(b.best_epoch)} được chọn bằng validation loss. Train loss giảm nhanh hơn validation cho thấy generalization gap; xem learning_curves.png cho cả mười cấu hình. Chỉ bốn epoch nên không khẳng định đã hội tụ. Các đường hữu hạn, không có NaN; điều đó chưa chứng minh mọi setting đều ổn định.

Confusion matrix dùng baseline được định trước, không chọn cấu hình có test F1 cao nhất. Accuracy={b.accuracy:.4f}, macro precision={b.precision:.4f}, macro recall={b.recall:.4f}, macro F1={b.f1:.4f}. Softmax probabilities chưa calibration. Các ví dụ application gồm câu ngắn, dài, phủ định, tương phản và cảm xúc mơ hồ; câu dài bị cắt 64 tokens nên có thể mất kết luận cuối.
'''
write('experiment_analysis.md',analysis)
verification=f'''# Đối chiếu prediction (không sửa prediction gốc)

|#|Dự đoán gốc|Kết quả quan sát / căn cứ|Đánh giá|Giải thích|
|---|---|---|---|---|
|1|Có thể song song hơn RNN|Q/K/V và scores tính theo ma trận trên toàn sequence; LSTM có phụ thuộc timestep.|Đúng về cấu trúc|Song song hóa không đồng nghĩa mọi trường hợp chạy nhanh hơn.|
|2|Không biết thứ tự nếu không có nguồn vị trí|Không PE: aligned-token difference {perm['without_pe']['aligned_token_max_abs_difference']:.6g}.|Đúng trong giả thiết thí nghiệm|Encoder hai chiều, không causal mask, không positional bias.|
|3|Mean pooling không phân biệt hoán vị nếu không PE|Pooled difference không PE {perm['without_pe']['mean_pool_max_abs_difference']:.6g}; có PE {perm['with_pe']['mean_pool_max_abs_difference']:.6f}.|Đúng|Ma trận đầu ra bị hoán vị; mean pooling bất biến.|
|4|Heads không nhất thiết giống nhau|Head diversity có differences khác 0 và entropy khác nhau.|Phù hợp quan sát|Không đảm bảo mỗi head có một vai trò ngôn ngữ riêng.|
|5|Thêm heads không chắc accuracy tăng|Accuracy h=1/2/4/8: {', '.join(f'{v:.4f}' for v in heads.accuracy)}.|Phù hợp quan sát|Không tăng đơn điệu; chỉ một seed.|
|6|Transformer không luôn nhanh hơn|Train LSTM {l.training_seconds:.2f}s, Transformer {b.training_seconds:.2f}s tại T=64; đã đo Transformer ở bốn T.|Chưa kiểm chứng tổng quát bằng timing|Không có LSTM timing ở mọi T hay GPU. Lập luận chi phí và cấu trúc hỗ trợ dự đoán; benchmark hiện tại không đủ chứng minh mệnh đề mọi length.|

Không phát hiện prediction bị bác bỏ trong phạm vi kiểm chứng; prediction 6 chỉ kiểm chứng một phần. Không sửa dự đoán gốc để khớp kết quả. Nếu một lượt chạy khác cho head accuracy tăng đơn điệu thì vẫn không chứng minh việc tăng heads luôn cải thiện. Không nhầm accuracy với khả năng song song hóa.
'''
write('prediction_verification.md',verification)

readme=f'''# LAB 07 — Transformer Architecture

Bài làm theo các yêu cầu trong w7.pdf, gồm lý thuyết, phép tính, core tự ghép, mười cấu hình thực nghiệm đã chạy, notebook có outputs, ứng dụng sentiment và phân tích lỗi. Toàn bộ kết quả là số đo CPU thực, không phải số minh họa.

## Mở bài làm

- Mở `transformer_classification.ipynb` để xem tuần tự toàn bộ bài.
- `calculations.md`: các phép tính, shape và giải thích thành phần.
- `prediction.md`: dự đoán ghi trước khi train; `prediction_verification.md`: đối chiếu riêng.
- `experiment_analysis.md`: bảng số liệu và nhận xét sáu nhóm thí nghiệm.
- `error_analysis.md`: ba dự đoán đúng, ba dự đoán sai trên test, quan sát attention.
- `reflection.md`: progression LAB 01–07, giới hạn, câu hỏi kiểm tra cá nhân và liên hệ BERT.

## Chạy lại

Dùng Python có các packages trong requirements.txt (đã chạy bằng Python {platform.python_version()}, PyTorch CPU). Từ thư mục repository:

```powershell
python -m pip install -r lab07/requirements.txt
python lab07/run_experiments.py --epochs 4
python lab07/build_reports.py
python lab07/build_notebook.py
python lab07/predict.py "I really enjoyed this movie."
```

Notebook mặc định đọc kết quả đã lưu; `RETRAIN=True` sẽ train lại, sau đó cần chạy build_reports.py để cập nhật phần văn bản. `build_notebook.py` thực thi toàn bộ cell và lưu outputs. Thời gian có thể khác giữa các máy/lượt chạy. Chạy tuần tự, tránh hai tiến trình cùng ghi kết quả.

## Dữ liệu và thiết kế

Nguồn: `../datasets/imdb/IMDB Dataset.csv`. Chọn 2.000 mẫu đầu mỗi nhãn, shuffle seed 42, train/validation/test=2.800/400/800. `split_manifest.csv` ghi dòng nguồn 0-based và nhãn từng mẫu, `data_audit.json` ghi hai training reviews bị thay để loại exact duplicate với held-out. Giữ nguyên validation/test. Vocab tối đa 7.500 từ thường + PAD/UNK/CLS, fit chỉ trên train. Lowercase, bỏ HTML br, regex letters/digits, split whitespace. Không dùng pretrained weights.

Không tìm thấy LAB 05; cách chọn mẫu và test dựa trên notebook LAB 06 ở Git HEAD. Tách validation từ phần train cũ. Đây là split ngẫu nhiên của CSV, không phải official IMDb benchmark. Exact duplicate audit không phát hiện gần trùng hoặc mọi loại leakage. Không đưa kết quả hiện tại thành tuyên bố benchmark chuẩn.

Cùng d_model=128, d_ff=256, 1 encoder block, dropout 0.1, batch=32, Adam lr=0.001, gradient clip=1, epochs=4, seed=42. Checkpoint chọn minimum validation loss. Precision/Recall/F1 là macro. LSTM hidden=128 dùng packed sequences và last hidden. Baseline Transformer=4 heads, length=64, masked mean pooling; baseline được định trước.

## Kết quả chính

{table(r.loc[['lstm','baseline','length_256'],['model','max_length','parameters','training_seconds','accuracy','f1']])}

Các ablation: heads=1/2/4/8; length=32/64/128/256; mean/CLS-style; có/không PE. Baseline dùng lại giữa các bảng để không train trùng cấu hình. Chỉ một seed/bốn epoch; cần nhiều seed và tuning trên validation để kết luận mạnh hơn. Memory scores trong results.csv là ước tính B×h×T²×4 bytes, không phải peak RAM. Training time loại validation/test, còn fit_wall_seconds gồm train và validation/chọn checkpoint. Thời gian không bao gồm data preparation.

## Thành phần thực thi và kiểm tra

`transformer_block.py`: tự chiếu Q/K/V, chia head, scale, key padding mask, softmax, nối heads, WO, residual, post-LayerNorm và FFN. Không dùng TransformerEncoderLayer hoặc MultiheadAttention cho core. PyTorch MultiheadAttention chỉ dùng làm reference trong checks().

`shape_checks.json` ghi kiểm tra B=8,T=100,d=128,h=4; chuẩn hóa attention; padding invariance; so với reference attention; finite gradients. `permutation_results.json` lưu token vectors của thí nghiệm hoán vị với embedding nhỏ tự chọn. Hai cặp câu dùng cùng bộ ba vector, không dùng embedding từ classifier.

`results.csv`, `history.json`, `test_predictions.csv`, `application_predictions.csv`, `head_diversity.json`, `error_examples.json`, `config.json` lưu số liệu thô. `transformer_model.pt` và `vocab.json` phục vụ inference. `positional_encoding.png`, `attention_heads.png`, `learning_curves.png`, `confusion_matrix.png` là bốn hình theo đề. Notebook có outputs hiển thị các hình và bảng.

Đề không cho giá trị X/WQ/WK/WV (mục 6), W2/b2 (mục 14); calculations.md giải tổng quát và ghi rõ ví dụ tự chọn. Peer assessment và phần vấn đáp cần người học/reviewer tự thực hiện; không tự nhận đã có đánh giá từ người khác.
'''
write('README.md',readme)
# Preserve provenance for the frozen predictions and source data.
write('provenance.json',json.dumps({'prediction_sha256':hashlib.sha256((ROOT/'prediction.md').read_bytes()).hexdigest(),'source_pdf_sha256':hashlib.sha256((ROOT.parent/'w7.pdf').read_bytes()).hexdigest(),'dataset_sha256':hashlib.sha256((ROOT.parent/'datasets/imdb/IMDB Dataset.csv').read_bytes()).hexdigest()},indent=2))
print('Reports generated.')

examples=json.loads((ROOT/'error_examples.json').read_text(encoding='utf-8'))
notes={
1291: ('Review dạng danh sách, nhiều tên diễn viên và số tuổi. Đoạn đầu có fine film và underrated nhưng không phải mọi nhận xét đều tích cực. Phần khen superb/best performance ở sau có thể bị cắt; dự đoán đúng không chứng minh mô hình hiểu toàn bài.', ['fine','underrated','brilliantly']),
369: ('Sentiment nhìn chung tích cực nhưng có contrast: solid acting, little long, cliché, cant help but like it. Tokenizer bỏ dấu câu và không chuẩn hóa cant thành can not; negation và noise dạng contraction là giới hạn tiền xử lý. Mô hình vẫn dự đoán đúng trên ví dụ này.', ['nice','solid','long','like']),
92: ('Review mở đầu bằng tên riêng và thông tin phim 1936, sau đó có sweet story. Nhiều lời khen rõ nhất ở phần sau không nằm trong cửa sổ 64 token. Tên riêng hiếm/domain-specific và truncation là yếu tố đáng kiểm tra; kết quả đúng có thể dựa trên ít tín hiệu đầu vào.', ['sweet']),
2688: ('Sai positive trên review negative. Phần đầu nói về những review khen phim đáng ngờ, không phải tác giả đang khen. Các cụm great reviews/good reviews mang sắc thái hoài nghi; mô hình có thể bị tín hiệu từ vựng tích cực lấn át. Kết luận fails to realise ở cuối bị cắt. Đây là giả thuyết hành vi, chưa có thử can thiệp để chứng minh.', ['great','suspiciously','good']),
2426: ('Sai positive trên nhãn negative. Nội dung có quite good, pretty good action và fine stars nhưng cũng có ridiculous plot và stupid B-action movies. Đây là cảm xúc pha trộn, nhãn toàn bài không dễ suy từ một cụm riêng; không khẳng định nhãn dữ liệu sai. Cửa sổ đầu giữ lời khen còn điều kiện If you don’t like... ở sau có thể bị mất.', ['good','ridiculous','fine']),
2317: ('Sai positive dù đoạn đầu có stupid, ridiculous, unfunny và below average. Nhiều token kể cốt truyện, tên riêng và thuật ngữ sequels/misadventure tạo nhiễu. Từ phủ định sắc thái unfunny có thể hiếm hoặc embedding học chưa tốt; cần ablation/đổi câu để xác minh. Truncation làm mất các nhận xét awful/disastrous ở sau, nhưng đoạn đầu vốn đã có tín hiệu negative nên không thể quy toàn bộ lỗi cho truncation.', ['stupid','ridiculous','unfunny','below','average'])
}
sections=['# Error analysis — 3 đúng và 3 sai\n\nChọn ba mẫu đúng đầu tiên và ba mẫu sai đầu tiên theo thứ tự test của baseline đã định trước. Không chọn theo độ đẹp của heatmap. source_row là chỉ số dòng 0-based trong CSV gốc. Nhãn và xác suất lấy từ test_predictions.csv; attention lấy từ cùng checkpoint eval mode.\n\nĐiểm attention dưới đây là mean received attention: trung bình qua bốn heads và các query thật, chỉ lấy 64 token được giữ lại. Đây không phải feature importance hay giải thích nhân quả.\n']
for i,e in enumerate(examples,1):
    note,important=notes.get(e['source_row'],('Cần đọc ngữ cảnh review và kiểm tra truncation; weights riêng lẻ chưa đủ xác định nguyên nhân.',[]))
    tokens=e['visible_text'].split(); top=e['attention_top_keys'];top_words={x['token'] for x in top}
    present=[w for w in important if w in tokens]; missing=[w for w in important if w not in tokens]
    label=lambda x:['Negative','Positive'][x]
    sections.append(f'''## {i}. {'Đúng' if e['target']==e['prediction'] else 'Sai'} — source_row {e['source_row']}

- Nhãn thật: **{label(e['target'])}**; dự đoán: **{label(e['prediction'])}**; P(Positive)={e['positive_probability']:.4f}.
- Độ dài gốc: {e['tokens']} tokens; giữ {min(e['tokens'],64)}; cắt {max(0,e['tokens']-64)}. Tỷ lệ UNK ở phần giữ lại: {e['oov_fraction']:.2%}.
- Phần mô hình thực sự đọc: `{e['visible_text']}`.

{note}

Top key nhận attention: {', '.join(f"{x['token']} (vị trí {x['position']}, {x['mean_received_attention']:.4f})" for x in top)}. Vị trí là 0-based sau tokenize. Các từ đáng kiểm tra còn trong cửa sổ: {', '.join(present) or 'không có trong danh sách'}; bị mất/không nằm trong đoạn giữ: {', '.join(missing) or 'không có'}. Trong các từ đáng kiểm tra còn thấy, từ lọt top-5 keys: {', '.join(w for w in present if w in top_words) or 'không có'}. Do attention này trung bình qua query/head, token quan trọng không lọt top-5 không có nghĩa model bỏ qua; token lọt top-5 cũng không chứng minh nó gây ra prediction.
''')
sections.append('''## Nhận xét và hướng cải thiện

Sáu ví dụ thể hiện contrast/ambiguous sentiment, phủ định và contraction, review dài/truncation, từ hiếm/tên riêng, thuật ngữ điện ảnh và noise sau tokenize. Mỗi yếu tố là một giả thuyết cần kiểm chứng, không tự xem là nguyên nhân của lỗi. Để thử: đánh giá riêng câu phủ định, giữ phần cuối review, tokenizer tốt hơn, tăng dữ liệu hoặc pretrained encoder; lựa chọn cấu hình dựa validation. Cần nhiều mẫu lỗi hơn để ước lượng tần suất các loại lỗi.

Không đồng nhất attention với explanation: trọng số còn đi cùng value vectors, output projection, residual, FFN, pooling và classifier. Attention visualization chỉ cho phân phối nội bộ; muốn kết luận nhân quả cần can thiệp có kiểm soát, ví dụ thay/cắt token và so sánh xác suất, đồng thời lưu ý distribution shift.
''')
write('error_analysis.md','\n'.join(sections))
