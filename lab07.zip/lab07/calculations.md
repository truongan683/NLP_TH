# Bài tính và lý thuyết LAB 07

## 1. Một attention head (mục 6)

Đề chỉ cho kích thước X (3×4), WQ/WK/WV (4×2), không cho các phần tử. Vì vậy không có nghiệm số duy nhất. Kết quả tổng quát: Q=XWQ, K=XWK, V=XWV đều 3×2; S=QKᵀ/√2 và A=softmax theo hàng đều 3×3; Z=AV là 3×2.

Ví dụ minh họa tự chọn, KHÔNG phải dữ kiện đề:

```text
X  = [[1,0,0,0], [0,1,0,0], [0,0,1,0]]
WQ = WK = WV = [[1,0], [0,1], [1,1], [0,0]]
Q = K = V = [[1,0], [0,1], [1,1]]
S = [[0.707107,0,0.707107],
     [0,0.707107,0.707107],
     [0.707107,0.707107,1.414214]]
A ≈ [[0.401112,0.197776,0.401112],
     [0.197776,0.401112,0.401112],
     [0.248255,0.248255,0.503490]]
Z ≈ [[0.802224,0.598888],
     [0.598888,0.802224],
     [0.751745,0.751745]]
```

Softmax hàng i: exp(Sij)/Σk exp(Sik). Chia √d_k giúp hạn chế độ lớn dot product khi số chiều tăng, tránh softmax quá bão hòa.

## 2. Multi-head (mục 7)

Hai head T×2 được nối thành T×4. Nếu đầu ra d_model=4 thì WO là 4×4. Nối giữ các đặc trưng riêng của từng head; WO học cách trộn thông tin giữa chúng và đưa kết quả về d_model để cộng residual. Cộng hai head trực tiếp sẽ mất định danh kênh và ràng buộc cách trộn. Concatenation là cách triển khai chuẩn; toán học có thể viết tương đương thành tổng các head nhân những khối tương ứng của WO.

Với d_model=128: heads=1/2/4/8 cho d_k=128/64/32/16. Tổng chiều sau nối luôn 128. Q/K/V/WO mỗi phép chiếu vẫn 128→128 nên số tham số attention không tăng theo số head khi d_model cố định. Có bias: 4×(128²+128)=66.048 tham số. d_ff=256: FFN có 65.920; hai LayerNorm có 512; toàn block có 132.480.

## 3. Positional encoding (mục 10)

Với d=4, PE(pos)=[sin(pos),cos(pos),sin(pos/100),cos(pos/100)]. Góc tính theo radian.

|pos|PE0|PE1|PE2|PE3|
|---|---|---|---|---|
|0|0.000000|1.000000|0.000000|1.000000|
|1|0.841471|0.540302|0.010000|0.999950|
|2|0.909297|-0.416147|0.019999|0.999800|

X'=X+PE cùng shape T×d. Mỗi vị trí có vector khác nhau. Không PE, attention hai chiều không mask nhân quả là permutation equivariant: F(PX)=PF(X). Chứng minh: Q'=PQ, K'=PK, V'=PV; softmax(PQKᵀPᵀ)=P softmax(QKᵀ)Pᵀ. FFN, LayerNorm theo feature và residual giữ tính chất này. Mean pooling khiến kết quả bất biến. Có PE cố định theo vị trí, PX+PE nói chung khác P(X+PE). Có PE chỉ cung cấp khả năng học thứ tự, không đảm bảo mô hình học được hoặc phân biệt mọi cặp câu.

## 4. FFN (mục 14)

x=[1,2]ᵀ; W1=I; b1=[0,-1]ᵀ. W1x+b1=[1,1]ᵀ; h=ReLU([1,1]ᵀ)=[1,1]ᵀ.

Đề không cung cấp W2, b2 nên chỉ suy ra y=W2[1,1]ᵀ+b2. Nếu W2=[[a,b],[c,d]], b2=[e,f]ᵀ thì y=[a+b+e,c+d+f]ᵀ. Không tự coi W2=I là dữ kiện đề.

FFN dùng cùng trọng số tại mỗi token, biến đổi phi tuyến theo feature; không trộn token như attention.

## 5. Residual, LayerNorm và encoder

Chỉ F(x) buộc nhánh biến đổi truyền mọi thông tin cần giữ. x+F(x) có đường truyền trực tiếp và đạo hàm I+J_F giúp gradient có một nhánh đi thẳng; không đảm bảo tuyệt đối không mất thông tin hay không bị vanishing gradient. Phải cùng chiều để cộng.

Post-norm của bài: U=LayerNorm(X+Dropout(MHA(X))); Y=LayerNorm(U+Dropout(FFN(U))). LayerNorm chuẩn hóa theo feature của từng token: γ⊙(x−μ)/√(σ²+ε)+β. Không chuẩn hóa qua batch; có tham số học γ, β. Dropout chỉ hoạt động lúc train.

Q: thông tin token đang tìm. K: thông tin dùng để khớp. V: nội dung được tổng hợp. Scores biểu diễn độ tương thích; attention là phân phối có tổng bằng 1 trên các key không padding.

## 6. Shape bắt buộc (mục 18)

|Bước|Shape|
|---|---|
|X|8×100×128|
|Q/K/V trước tách head|8×100×128|
|Q/K/V sau tách|8×4×100×32|
|Scores và attention weights|8×4×100×100|
|A V từng head|8×4×100×32|
|Nối head và WO|8×100×128|
|Residual + Norm 1|8×100×128|
|FFN linear 1 / activation|8×100×256|
|FFN linear 2|8×100×128|
|Residual + Norm 2 / output|8×100×128|

Mask key padding có shape B×1×1×T; logits tại key padding = −∞ trước softmax. Output tại query padding được đặt 0, và mean pooling chỉ lấy token thật. LSTM dùng packed sequence để không lấy hidden state sau padding.

## 7. Chi phí sequence length

Có T query, mỗi query so với T key nên scores là T×T. Attention compute O(BT²d_model), thêm projection/FFN O(BT d_model² + BT d_model d_ff); bộ nhớ scores O(BhT²). 128→256 tăng 4 lần số phần tử scores, chưa tính gradient và các buffer trung gian. B=32,h=4,float32: length 32/64/128/256 cần riêng một tensor scores 0,5/2/8/32 MiB. Đây là ước tính, không phải peak RAM đo thực. Tăng T còn giữ thêm token và giảm truncation nhưng tăng chi phí, padding và có thể thêm nhiễu.

## 8. Pooling

Mean pooling: Σt mask_t H_t / Σt mask_t. First-token không mặc nhiên là CLS: thí nghiệm CLS ở đây thêm token <CLS> học được ở đầu vào và train lại. Cùng 64 review tokens, CLS có tổng 65 vị trí. Vì vậy có khác biệt nhỏ về computation, được ghi rõ trong kết quả.

