# Đối chiếu prediction (không sửa prediction gốc)

|#|Dự đoán gốc|Kết quả quan sát / căn cứ|Đánh giá|Giải thích|
|---|---|---|---|---|
|1|Có thể song song hơn RNN|Q/K/V và scores tính theo ma trận trên toàn sequence; LSTM có phụ thuộc timestep.|Đúng về cấu trúc|Song song hóa không đồng nghĩa mọi trường hợp chạy nhanh hơn.|
|2|Không biết thứ tự nếu không có nguồn vị trí|Không PE: aligned-token difference 0.|Đúng trong giả thiết thí nghiệm|Encoder hai chiều, không causal mask, không positional bias.|
|3|Mean pooling không phân biệt hoán vị nếu không PE|Pooled difference không PE 0; có PE 0.267565.|Đúng|Ma trận đầu ra bị hoán vị; mean pooling bất biến.|
|4|Heads không nhất thiết giống nhau|Head diversity có differences khác 0 và entropy khác nhau.|Phù hợp quan sát|Không đảm bảo mỗi head có một vai trò ngôn ngữ riêng.|
|5|Thêm heads không chắc accuracy tăng|Accuracy h=1/2/4/8: 0.7000, 0.6750, 0.6562, 0.6975.|Phù hợp quan sát|Không tăng đơn điệu; chỉ một seed.|
|6|Transformer không luôn nhanh hơn|Train LSTM 16.66s, Transformer 13.28s tại T=64; đã đo Transformer ở bốn T.|Chưa kiểm chứng tổng quát bằng timing|Không có LSTM timing ở mọi T hay GPU. Lập luận chi phí và cấu trúc hỗ trợ dự đoán; benchmark hiện tại không đủ chứng minh mệnh đề mọi length.|

Không phát hiện prediction bị bác bỏ trong phạm vi kiểm chứng; prediction 6 chỉ kiểm chứng một phần. Không sửa dự đoán gốc để khớp kết quả. Nếu một lượt chạy khác cho head accuracy tăng đơn điệu thì vẫn không chứng minh việc tăng heads luôn cải thiện. Không nhầm accuracy với khả năng song song hóa.
