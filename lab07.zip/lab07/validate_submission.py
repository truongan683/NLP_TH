"""Check consistency of the submission without retraining."""
from pathlib import Path
import json
import nbformat
import pandas as pd
from sklearn.metrics import accuracy_score, precision_recall_fscore_support
ROOT=Path(__file__).resolve().parent
required=['README.md','calculations.md','prediction.md','transformer_block.py','positional_encoding.py','transformer_classification.ipynb','results.csv','positional_encoding.png','attention_heads.png','learning_curves.png','confusion_matrix.png','error_analysis.md','reflection.md']
assert all((ROOT/name).is_file() and (ROOT/name).stat().st_size for name in required)
r=pd.read_csv(ROOT/'results.csv'); assert len(r)==10 and r.experiment.is_unique
p=pd.read_csv(ROOT/'test_predictions.csv'); assert len(p)==800
baseline=r[r.experiment.eq('baseline')].iloc[0]
assert abs(accuracy_score(p.target,p.prediction)-baseline.accuracy)<1e-10
precision,recall,f1,_=precision_recall_fscore_support(p.target,p.prediction,average='macro')
assert abs(f1-baseline.f1)<1e-10 and abs(precision-baseline.precision)<1e-10 and abs(recall-baseline.recall)<1e-10
nb=nbformat.read(ROOT/'transformer_classification.ipynb',as_version=4);nbformat.validate(nb)
code=[c for c in nb.cells if c.cell_type=='code']
if all(c.execution_count is None for c in code):
    assert all(not c.outputs for c in code)
    for c in code: compile(c.source, '<notebook>', 'exec')
else:
    assert all(c.execution_count is not None for c in code)
assert not [o for c in code for o in c.outputs if o.output_type=='error']
audit=json.loads((ROOT/'data_audit.json').read_text());assert audit['train_heldout_exact_overlap_after']==0 and audit['validation_test_exact_overlap']==0
manifest=pd.read_csv(ROOT/'split_manifest.csv');assert manifest.groupby('split').size().to_dict()=={'test':800,'train':2800,'validation':400}
examples=json.loads((ROOT/'error_examples.json').read_text(encoding='utf-8'))
assert sum(e['target']==e['prediction'] for e in examples)==3 and sum(e['target']!=e['prediction'] for e in examples)==3
history=json.loads((ROOT/'history.json').read_text());assert len(history)==10 and all(len(v)==4 for v in history.values())
print(f'PASS: {len(required)} required files; 10 experiments; 40 epochs; {len(code)} valid notebook cells; metrics consistent; 3 correct + 3 incorrect; no exact overlap.')
