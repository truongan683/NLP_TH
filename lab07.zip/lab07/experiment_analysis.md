# Phân tích kết quả thực nghiệm

Các số dưới đây lấy trực tiếp từ results.csv. Một seed 42, bốn epochs; không có kiểm định ý nghĩa thống kê.

## 1. Positional information

Không PE: max chênh token sau căn chỉnh = 0; chênh mean pooling = 0. Có PE: hai đại lượng = 1.708541 và 0.267565. Đây là bằng chứng thực nghiệm về symmetry và việc PE phá symmetry đó, không chỉ là phát biểu lý thuyết. File permutation_results.json lưu toàn bộ token representations.

Ablation trên classification: baseline F1=0.6493, no-PE F1=0.7122. Dataset sentiment có nhiều tín hiệu bag-of-words; lợi ích PE không nhất thiết hiện rõ trên subset ngắn và một seed. Không được dùng kết quả này để phủ nhận tính cần thiết của thông tin vị trí khi tác vụ đòi phân biệt thứ tự.

## 2. Number of heads

| heads | d_k | parameters | training_seconds | accuracy | f1 |
| --- | --- | --- | --- | --- | --- |
| 1 | 128 | 1093122 | 11.3283 | 0.7000 | 0.6992 |
| 2 | 64 | 1093122 | 11.9386 | 0.6750 | 0.6728 |
| 4 | 32 | 1093122 | 13.2761 | 0.6562 | 0.6493 |
| 8 | 16 | 1093122 | 15.7080 | 0.6975 | 0.6925 |

Số chiều nối luôn 128 và số tham số các model Transformer bằng nhau. F1 không tăng đơn điệu theo số heads trong lượt chạy này. Các thay đổi phản ánh cách chia không gian attention, softmax riêng và đường tối ưu; không chứng minh càng nhiều heads càng tốt. Số phần tử scores tăng tuyến tính theo h dù tổng chiều embedding cố định.

## 3. Head diversity

Câu quan sát: `the movie was not good but the acting was excellent`. Entropy trung bình (thấp hơn nghĩa tập trung hơn trên cùng số token):

| head | mean_entropy | mean_max_weight |
| --- | --- | --- |
| 1 | 0.0905 | 0.9862 |
| 2 | 0.7911 | 0.7787 |
| 3 | 1.6607 | 0.4719 |
| 4 | 1.7386 | 0.3479 |

| pair | mean_absolute_difference |
| --- | --- |
| [1, 2] | 0.0420 |
| [1, 3] | 0.1827 |
| [1, 4] | 0.1932 |
| [2, 3] | 0.1543 |
| [2, 4] | 0.1643 |
| [3, 4] | 0.0750 |

Head tập trung nhất theo entropy là head 1; phân tán nhất là head 4. Các chênh lệch giữa heads cho thấy patterns không hoàn toàn trùng nhau trên câu này. Cặp gần nhất theo mean absolute difference là [1, 2]. Chỉ một câu chưa đủ kết luận head redundant trên toàn dataset; cần đo trên nhiều câu và thử ablation head. Không gán head với syntax/semantics và không coi heatmap là giải thích nhân quả.

## 4. LSTM vs Transformer

| model | parameters | training_seconds | accuracy | precision | recall | f1 |
| --- | --- | --- | --- | --- | --- | --- |
| LSTM | 1092738 | 16.6595 | 0.5275 | 0.5333 | 0.5316 | 0.5230 |
| Transformer | 1093122 | 13.2761 | 0.6562 | 0.6799 | 0.6620 | 0.6493 |

Giữ cùng dữ liệu, vocab, embedding dimension, batch, optimizer, learning rate, epochs. LSTM dùng last hidden của packed sequence; Transformer dùng mean pooling và FFN/residual/norm/dropout. Số tham số gần nhau nhưng không bằng tuyệt đối. Khác biệt gồm đường truyền dài của LSTM, tương tác trực tiếp của attention, pooling và regularization. LSTM có train loss giảm trong khi validation xấu đi, cho thấy overfitting trong cấu hình này; không đủ cơ sở suy ra LSTM luôn kém. Cần tuning độc lập trên validation và nhiều seed cho so sánh mạnh hơn.

## 5. Sequence length

| max_length | tokens_retained | attention_mib | training_seconds | f1 |
| --- | --- | --- | --- | --- |
| 32 | 0.1323 | 0.5000 | 7.2453 | 0.6254 |
| 64 | 0.2627 | 2.0000 | 13.2761 | 0.6493 |
| 128 | 0.4983 | 8.0000 | 30.9255 | 0.7306 |
| 256 | 0.7626 | 32.0000 | 82.9957 | 0.7712 |

Tỷ lệ token giữ lại là micro token retention trên test, không phải phần trăm review nguyên vẹn. Cùng B=32,h=4,float32, riêng scores tăng 8→32 MiB khi length 128→256. Đây là bộ nhớ lý thuyết của một tensor; code còn tạo weights, gradients, intermediate activations. Không có phép đo peak RAM. Thời gian train cũng gồm projection/FFN/optimizer nên không nhất thiết tăng đúng bốn lần. Độ dài lớn giảm mất thông tin nhưng tăng chi phí và có thể giữ thêm noise.

## 6. Pooling

| pooling | accuracy | f1 | training_seconds |
| --- | --- | --- | --- |
| mean | 0.6562 | 0.6493 | 13.2761 |
| cls | 0.6562 | 0.6562 | 13.8637 |

CLS-style thêm token <CLS> và được train từ đầu; không lấy token đầu tiên của review rồi gọi là CLS. Giữ 64 review tokens ở cả hai nên CLS có 65 positions. Cách tổng hợp ảnh hưởng kết quả; khác biệt này không phải so sánh với pretrained BERT CLS. Mean pooling nhận tín hiệu từ mọi token qua đường trực tiếp; CLS phải học thu thập thông tin qua attention.

## 7. Learning curves và đánh giá

Baseline train loss: 0.6749, 0.5814, 0.4909, 0.3869. Validation loss: 0.6003, 0.5612, 0.5632, 0.5969. Checkpoint epoch 2 được chọn bằng validation loss. Train loss giảm nhanh hơn validation cho thấy generalization gap; xem learning_curves.png cho cả mười cấu hình. Chỉ bốn epoch nên không khẳng định đã hội tụ. Các đường hữu hạn, không có NaN; điều đó chưa chứng minh mọi setting đều ổn định.

Confusion matrix dùng baseline được định trước, không chọn cấu hình có test F1 cao nhất. Accuracy=0.6562, macro precision=0.6799, macro recall=0.6620, macro F1=0.6493. Softmax probabilities chưa calibration. Các ví dụ application gồm câu ngắn, dài, phủ định, tương phản và cảm xúc mơ hồ; câu dài bị cắt 64 tokens nên có thể mất kết luận cuối.
