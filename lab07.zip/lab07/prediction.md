# Dự đoán trước thí nghiệm

Được ghi trước khi chạy run_experiments.py. Không sửa các dự đoán dưới đây sau khi có số liệu.

| # | Prediction | Reason | Confidence |
|---|---|---|---|
|1|Có, Transformer song song hóa theo token tốt hơn RNN.|Q/K/V và attention tính bằng phép nhân ma trận; RNN phụ thuộc hidden state bước trước.|99%|
|2|Không biết thứ tự tuyệt đối nếu không có nguồn vị trí nào khác.|Self-attention và FFN chia sẻ trọng số theo vị trí.|99%|
|3|Không phân biệt bằng mean pooling trong encoder hai chiều không PE, eval mode.|Hoán vị đầu vào hoán vị đầu ra; mean pooling bất biến theo hoán vị.|99%|
|4|Không nhất thiết giống nhau.|Các projection khác nhau có thể học phân phối khác nhau, nhưng không đảm bảo chuyên môn hóa.|95%|
|5|Không chắc accuracy tăng khi thêm heads.|d_model cố định khiến mỗi head hẹp hơn; phụ thuộc dữ liệu và tối ưu.|95%|
|6|Không luôn nhanh hơn.|Attention có chi phí bậc hai theo T; tốc độ phụ thuộc CPU/GPU, batch, kernel và chiều ẩn.|95%|

Lưu ý prediction 3: representation token theo vị trí có thể khác nhau sau hoán vị; cần căn chỉnh token hoặc so sánh pooled representation, không so hai ma trận theo cùng chỉ số rồi kết luận mô hình hiểu thứ tự.

Kết quả đối chiếu được lưu riêng trong prediction_verification.md để giữ nguyên dự đoán.
