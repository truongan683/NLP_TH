"""Predict sentiment using the saved custom Transformer checkpoint."""
import argparse
from pathlib import Path
import torch
from run_experiments import Classifier, encode, tokenize

if __name__ == '__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('text')
    args=parser.parse_args()
    checkpoint=torch.load(Path(__file__).with_name('transformer_model.pt'),map_location='cpu',weights_only=True)
    model=Classifier(len(checkpoint['vocab']),heads=checkpoint['heads'])
    model.load_state_dict(checkpoint['state_dict']);model.eval()
    tokens=tokenize(args.text)
    with torch.no_grad():
        probs=model(encode([tokens],checkpoint['vocab'],checkpoint['max_length'])).softmax(-1)[0]
    label=int(probs.argmax())
    print(f'{["Negative","Positive"][label]} | Probability: {probs[label].item():.4f}')
    print(f'Tokens: {len(tokens)} | retained: {min(len(tokens),checkpoint["max_length"])}')
