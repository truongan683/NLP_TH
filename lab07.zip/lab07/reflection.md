# Reflection và kiểm tra hiểu bài

## Từ LAB 01 đến LAB 07

LAB 01 dùng biểu diễn TF-IDF thưa để tìm kiếm; LAB 02 dùng n-gram ước lượng xác suất chuỗi nhưng giới hạn ngữ cảnh và gặp sparsity; LAB 03 dùng embedding dày để mô hình hóa gần nhau về ngữ nghĩa; LAB 04 đưa representation vào classification và đánh giá; LAB 05 học thứ tự bằng mô hình recurrent; LAB 06 dùng attention tổng hợp thông tin theo truy vấn; LAB 07 ghép attention thành encoder đầy đủ với vị trí, FFN, residual và normalization.

|Bước|Hạn chế|Bước tiếp giải quyết gì?|
|---|---|---|
|TF-IDF|Vector thưa, từ đồng nghĩa không tự gần nhau, khó biểu diễn ngữ cảnh; bag-of-words mất thứ tự.|Word2Vec học quan hệ phân phối trong không gian dày.|
|Average Word2Vec|Embedding tĩnh; trung bình bỏ thứ tự, khó hiểu phủ định.|LSTM cập nhật hidden state theo thứ tự.|
|LSTM|Tính tuần tự; thông tin xa đi qua nhiều bước, hidden state có thể thành nút thắt.|Attention kết nối trực tiếp các vị trí để lấy nội dung liên quan.|
|Attention đơn lẻ|Chưa có đầy đủ xử lý vị trí, nhiều không gian tương tác và các thành phần ổn định tối ưu.|Transformer bổ sung multi-head, PE, FFN, residual và LayerNorm.|
|Transformer học từ đầu|Attention bậc hai; truncation; cần dữ liệu; chưa có tri thức từ pretraining; không tự đảm bảo hiểu ngôn ngữ.|LAB 08 dùng pretrained encoder/BERT rồi fine-tune.|

## Bảng so sánh

|Thuộc tính|TF-IDF|Avg Word2Vec|LSTM|Self-attention đơn lẻ|Transformer encoder|
|---|---|---|---|---|---|
|Representation|Sparse|Dense|Dense|Dense|Dense|
|Word order|Chỉ một phần nếu có n-gram|Không|Có, implicit|Cần thêm vị trí hoặc ngữ cảnh recurrent|Cần positional information|
|Context-dependent|Không|Không|Có|Có|Có|
|Tương tác trực tiếp giữa token|Không|Không|Qua chuỗi hidden state|Có|Có|
|Tuần tự theo token|Không|Không|Có|Không bắt buộc|Không ở encoder hai chiều|
|Song song hóa|Tốt|Tốt|Hạn chế theo T|Tốt|Tốt|
|Quan hệ xa|Hạn chế|Không biểu diễn quan hệ thứ tự|Khó hơn khi đường truyền dài|Đường truyền trực tiếp|Đường truyền trực tiếp|
|Attention|Không|Không|Không, nếu LSTM thuần|Có|Có|
|Chi phí theo T (cố định chiều)|Gần tuyến tính|Tuyến tính|Tuyến tính nhưng tuần tự|Bậc hai|Bậc hai, cộng FFN tuyến tính theo T|

Không nên coi bảng là thứ hạng tuyệt đối: TF-IDF thường là baseline mạnh trên ít dữ liệu, LSTM có thể phù hợp khi tài nguyên hoặc luồng dữ liệu yêu cầu xử lý tuần tự. Head attention không tự mang nhãn syntax/semantics; quan sát khác biệt weights không chứng minh đã học một quy tắc ngôn ngữ.

## Câu hỏi tự kiểm tra trong 3 phút

1. **Tại sao PE?** Không có vị trí, encoder hai chiều permutation equivariant; mean pooling bất biến với hoán vị.
2. **Multi-head khác single-head?** Nhiều Q/K/V projections tạo các attention distribution riêng; nối rồi chiếu WO. Không đảm bảo mọi head khác biệt.
3. **128 chiều, 8 heads?** d_k=16; nối 8 head vẫn 128 chiều.
4. **Tại sao T×T?** Mỗi trong T query khớp với cả T key.
5. **Residual làm gì?** Thêm đường truyền thông tin và gradient trực tiếp.
6. **FFN làm gì?** Biến đổi phi tuyến theo feature tại từng token, dùng chung trọng số.
7. **Tại sao song song hơn RNN?** Không phải chờ hidden state của token trước trong cùng encoder layer.
8. **Gấp đôi T?** Gấp bốn số phần tử scores cho cùng batch/heads; tổng thời gian không nhất thiết đúng gấp bốn.
9. **Tại sao attention không phải explanation?** Weights là một thành phần nội bộ; V, projection, FFN, residual, pooling và classifier cũng quyết định output. Cần can thiệp có kiểm soát để thử quan hệ nhân quả; heatmap đơn lẻ không đủ.
10. **LayerNorm theo chiều nào?** Feature cuối của từng token, độc lập từng mẫu trong batch.

## Giới hạn thực nghiệm

Chỉ một seed và bốn epoch trên subset 4.000 IMDb reviews, không có pretrained embedding. Không tìm thấy bài LAB 05 trong workspace nên chỉ tái sử dụng nguồn dữ liệu và cách chọn mẫu/tập test của LAB 06 khôi phục được từ Git. LSTM được train mới với d_model=128, cùng optimizer, learning rate, batch, split và epochs; không tái sử dụng số liệu cũ có embedding dimension 32. Validation được tách riêng để chọn checkpoint, không chọn theo test. Các thí nghiệm test là phân tích mô tả, không dùng để tuyên bố mô hình tối ưu hay hiệu quả thống kê.
