"""Generate an output-free notebook that actually trains the six experiments."""
from pathlib import Path
import nbformat
root=Path(__file__).resolve().parent
md=nbformat.v4.new_markdown_cell
code=nbformat.v4.new_code_cell
source=(root/'run_experiments.py').read_text(encoding='utf-8-sig').split("if __name__=='__main__':")[0]
source=source.replace('ROOT = Path(__file__).resolve().parent','ROOT = OUTPUT_DIR').replace('DATA_PATH = ROOT.parent / "datasets/imdb/IMDB Dataset.csv"','DATA_PATH = DATASET_PATH')
setup='''from pathlib import Path
import sys
import torch

# Sửa đường dẫn này khi chạy trên Colab/Kaggle hoặc máy khác.
DATASET_PATH = Path('datasets/imdb/IMDB Dataset.csv').resolve()
if not DATASET_PATH.exists():
    DATASET_PATH = Path('../datasets/imdb/IMDB Dataset.csv').resolve()
OUTPUT_DIR = Path('training_output').resolve()
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

# Hai module này đặt cùng notebook, hoặc trong lab07/.
MODULE_DIR = Path.cwd() if (Path.cwd() / 'transformer_block.py').exists() else Path.cwd() / 'lab07'
sys.path.insert(0, str(MODULE_DIR))
EPOCHS = 4
DEVICE = 'auto'  # auto: CUDA nếu có, ngược lại CPU; đặt 'cuda' để bắt buộc GPU.
if not DATASET_PATH.is_file():
    raise FileNotFoundError(f'Sửa DATASET_PATH cho đúng: {DATASET_PATH}')
'''
cells=[md('''# LAB 07 — Experiments (training)

Chạy **Run All** để huấn luyện lại từ đầu. Notebook không hiển thị bảng/hình có sẵn; chỉ in tiến độ training và lưu CSV, checkpoint, JSON, PNG vào `training_output/`. Kết quả cũ không được nhúng vào notebook.

Cần notebook, `transformer_block.py`, `positional_encoding.py`, dữ liệu IMDb CSV và các thư viện trong requirements.txt. Chọn runtime GPU và cài PyTorch hỗ trợ CUDA để dùng NVIDIA GPU. `DEVICE='auto'` tự chọn CUDA hoặc CPU; `DEVICE='cuda'` báo lỗi nếu không dùng được CUDA. Đổi `EPOCHS`, `DATASET_PATH`, `OUTPUT_DIR` ở cell cấu hình. Dữ liệu 4.000 mẫu; train/validation/test=2.800/400/800; seed 42.'''),code(setup),
md('## Hàm dùng chung\nTokenizer, dataset, classifier, train/evaluate và lưu kết quả. Model và batch được chuyển sang cùng device; checkpoint lưu tensor CPU để có thể nạp trên máy khác.'),code(source),
md('## Experiment 1 — Positional encoding và permutation\nChạy phép thử hoán vị; lưu representations và biểu đồ PE. Không có bước huấn luyện ở phép thử nhỏ này.'),code('checks()\n_ = permutation_experiment()'),
md('## Experiment 2 — Number of attention heads\nHuấn luyện 1/2/4/8 heads, cùng d_model=128; lưu baseline 4 heads cho các phép so sánh sau.'),code("_ = run(epochs=EPOCHS, device=DEVICE, experiment_names=['heads_1','heads_2','baseline','heads_8'], finalize=False)"),
md('## Experiment 3 — Attention head diversity\nDùng baseline vừa train ở Experiment 2, tính entropy và khác biệt giữa heads; lưu attention_heads.png và head_diversity.json. Không cần huấn luyện thêm mô hình.'),code('finalize_experiments(device=DEVICE)'),
md('## Experiment 4 — Transformer vs LSTM\nTrain LSTM với cùng split, vocab, embedding dimension, batch, optimizer, learning rate và epochs; so sánh với baseline Transformer đã train.'),code("_ = run(epochs=EPOCHS, device=DEVICE, experiment_names=['lstm'], finalize=False)"),
md('## Experiment 5 — Sequence length\nTrain length=32/128/256; length=64 dùng lại baseline. Lưu token retention, scores memory, thời gian và F1.'),code("_ = run(epochs=EPOCHS, device=DEVICE, experiment_names=['length_32','length_128','length_256'], finalize=False)"),
md('## Experiment 6 — Pooling strategy\nTrain CLS-style và ablation không PE; so sánh với baseline mean pooling. Sau cùng lưu lại learning curves, confusion matrix và attention từ lượt chạy mới.'),code("_ = run(epochs=EPOCHS, device=DEVICE, experiment_names=['pool_cls','no_pe'], finalize=False)\nfinalize_experiments(device=DEVICE)")]
nb=nbformat.v4.new_notebook(cells=cells,metadata={'kernelspec':{'display_name':'Python 3','language':'python','name':'python3'},'language_info':{'name':'python'}})
for path in [root/'transformer_classification.ipynb',root.parent/'transformer_classification.ipynb']:
    nbformat.write(nb,path)
print('Saved training notebook with no saved outputs.')
