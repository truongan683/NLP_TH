# Error analysis — 3 đúng và 3 sai

Chọn ba mẫu đúng đầu tiên và ba mẫu sai đầu tiên theo thứ tự test của baseline đã định trước. Không chọn theo độ đẹp của heatmap. source_row là chỉ số dòng 0-based trong CSV gốc. Nhãn và xác suất lấy từ test_predictions.csv; attention lấy từ cùng checkpoint eval mode.

Điểm attention dưới đây là mean received attention: trung bình qua bốn heads và các query thật, chỉ lấy 64 token được giữ lại. Đây không phải feature importance hay giải thích nhân quả.

## 1. Đúng — source_row 1291

- Nhãn thật: **Positive**; dự đoán: **Positive**; P(Positive)=0.7212.
- Độ dài gốc: 288 tokens; giữ 64; cắt 224. Tỷ lệ UNK ở phần giữ lại: 3.12%.
- Phần mô hình thực sự đọc: `since there have been so many reviews of this fine film i will write in a list form and attempt to address issues that have not been discussed 1 dana andrews was 38 during the filming of this movie his character according to the screenplay was in his mid 20s andrews a highly underrated actor did brilliantly play a character who was supposed to`.

Review dạng danh sách, nhiều tên diễn viên và số tuổi. Đoạn đầu có fine film và underrated nhưng không phải mọi nhận xét đều tích cực. Phần khen superb/best performance ở sau có thể bị cắt; dự đoán đúng không chứng minh mô hình hiểu toàn bài.

Top key nhận attention: not (vị trí 25, 0.0446), discussed (vị trí 27, 0.0441), screenplay (vị trí 44, 0.0397), actor (vị trí 54, 0.0379), play (vị trí 57, 0.0369). Vị trí là 0-based sau tokenize. Các từ đáng kiểm tra còn trong cửa sổ: fine, underrated, brilliantly; bị mất/không nằm trong đoạn giữ: không có. Trong các từ đáng kiểm tra còn thấy, từ lọt top-5 keys: không có. Do attention này trung bình qua query/head, token quan trọng không lọt top-5 không có nghĩa model bỏ qua; token lọt top-5 cũng không chứng minh nó gây ra prediction.

## 2. Đúng — source_row 369

- Nhãn thật: **Positive**; dự đoán: **Positive**; P(Positive)=0.8612.
- Độ dài gốc: 107 tokens; giữ 64; cắt 43. Tỷ lệ UNK ở phần giữ lại: 3.12%.
- Phần mô hình thực sự đọc: `it s nice to see a romantic comedy that does not have the prissy man lead this has solid acting from both male leads and also from the female lead and although the story is a little long and a little clich you cant help but like it i think the story was a little rushed at the end but extending that would have`.

Sentiment nhìn chung tích cực nhưng có contrast: solid acting, little long, cliché, cant help but like it. Tokenizer bỏ dấu câu và không chuẩn hóa cant thành can not; negation và noise dạng contraction là giới hạn tiền xử lý. Mô hình vẫn dự đoán đúng trên ví dụ này.

Top key nhận attention: story (vị trí 33, 0.0761), like (vị trí 46, 0.0634), also (vị trí 25, 0.0556), you (vị trí 42, 0.0550), lead (vị trí 29, 0.0423). Vị trí là 0-based sau tokenize. Các từ đáng kiểm tra còn trong cửa sổ: nice, solid, long, like; bị mất/không nằm trong đoạn giữ: không có. Trong các từ đáng kiểm tra còn thấy, từ lọt top-5 keys: like. Do attention này trung bình qua query/head, token quan trọng không lọt top-5 không có nghĩa model bỏ qua; token lọt top-5 cũng không chứng minh nó gây ra prediction.

## 3. Đúng — source_row 92

- Nhãn thật: **Positive**; dự đoán: **Positive**; P(Positive)=0.9013.
- Độ dài gốc: 399 tokens; giữ 64; cắt 335. Tỷ lệ UNK ở phần giữ lại: 21.88%.
- Phần mô hình thực sự đọc: `deanna durbin nan grey and barbara read are three smart girls in this universal film from 1936 which introduces deanna durbin to film audiences it also stars ray milland mischa auer charles winninger john king binnie barnes and alice brady it s a sweet story about three young women now living in switzerland with their divorced mother who hear their father winninger is marrying`.

Review mở đầu bằng tên riêng và thông tin phim 1936, sau đó có sweet story. Nhiều lời khen rõ nhất ở phần sau không nằm trong cửa sổ 64 token. Tên riêng hiếm/domain-specific và truncation là yếu tố đáng kiểm tra; kết quả đúng có thể dựa trên ít tín hiệu đầu vào.

Top key nhận attention: story (vị trí 44, 0.1053), and (vị trí 4, 0.0734), alice (vị trí 38, 0.0561), universal (vị trí 13, 0.0469), girls (vị trí 10, 0.0468). Vị trí là 0-based sau tokenize. Các từ đáng kiểm tra còn trong cửa sổ: sweet; bị mất/không nằm trong đoạn giữ: không có. Trong các từ đáng kiểm tra còn thấy, từ lọt top-5 keys: không có. Do attention này trung bình qua query/head, token quan trọng không lọt top-5 không có nghĩa model bỏ qua; token lọt top-5 cũng không chứng minh nó gây ra prediction.

## 4. Sai — source_row 2688

- Nhãn thật: **Negative**; dự đoán: **Positive**; P(Positive)=0.7236.
- Độ dài gốc: 318 tokens; giữ 64; cắt 254. Tỷ lệ UNK ở phần giữ lại: 4.69%.
- Phần mô hình thực sự đọc: `it s somewhat telling that most of the great reviews for the film on imdb all come from people who have only reviewed one film in their entire imdb career and yes you ve guessed it that film is parasomnia i ve often suspected suspiciously good reviews on imdb for what turns out to be an anything but good films as underhand marketing but`.

Sai positive trên review negative. Phần đầu nói về những review khen phim đáng ngờ, không phải tác giả đang khen. Các cụm great reviews/good reviews mang sắc thái hoài nghi; mô hình có thể bị tín hiệu từ vựng tích cực lấn át. Kết luận fails to realise ở cuối bị cắt. Đây là giả thuyết hành vi, chưa có thử can thiệp để chứng minh.

Top key nhận attention: ve (vị trí 41, 0.0655), ve (vị trí 33, 0.0478), good (vị trí 58, 0.0469), good (vị trí 45, 0.0434), anything (vị trí 56, 0.0375). Vị trí là 0-based sau tokenize. Các từ đáng kiểm tra còn trong cửa sổ: great, suspiciously, good; bị mất/không nằm trong đoạn giữ: không có. Trong các từ đáng kiểm tra còn thấy, từ lọt top-5 keys: good. Do attention này trung bình qua query/head, token quan trọng không lọt top-5 không có nghĩa model bỏ qua; token lọt top-5 cũng không chứng minh nó gây ra prediction.

## 5. Sai — source_row 2426

- Nhãn thật: **Negative**; dự đoán: **Positive**; P(Positive)=0.8066.
- Độ dài gốc: 83 tokens; giữ 64; cắt 19. Tỷ lệ UNK ở phần giữ lại: 9.38%.
- Phần mô hình thực sự đọc: `it s die hard meets cliffhanger when a ski resort is besieged by terrorists and it s up to one cop jack crackerjack to stop this a b action movie that borrows from other films and is quite good with pretty good action a ridiculous plot as always in these movies and three fine stars thomas ian griffith as the cop and nastasja kinski`.

Sai positive trên nhãn negative. Nội dung có quite good, pretty good action và fine stars nhưng cũng có ridiculous plot và stupid B-action movies. Đây là cảm xúc pha trộn, nhãn toàn bài không dễ suy từ một cụm riêng; không khẳng định nhãn dữ liệu sai. Cửa sổ đầu giữ lời khen còn điều kiện If you don’t like... ở sau có thể bị mất.

Top key nhận attention: terrorists (vị trí 13, 0.1176), plot (vị trí 45, 0.0983), griffith (vị trí 57, 0.0421), and (vị trí 51, 0.0352), cop (vị trí 20, 0.0346). Vị trí là 0-based sau tokenize. Các từ đáng kiểm tra còn trong cửa sổ: good, ridiculous, fine; bị mất/không nằm trong đoạn giữ: không có. Trong các từ đáng kiểm tra còn thấy, từ lọt top-5 keys: không có. Do attention này trung bình qua query/head, token quan trọng không lọt top-5 không có nghĩa model bỏ qua; token lọt top-5 cũng không chứng minh nó gây ra prediction.

## 6. Sai — source_row 2317

- Nhãn thật: **Negative**; dự đoán: **Positive**; P(Positive)=0.6806.
- Độ dài gốc: 204 tokens; giữ 64; cắt 140. Tỷ lệ UNK ở phần giữ lại: 9.38%.
- Phần mô hình thực sự đọc: `the goofy griswalds win the t v game show pig in a poke grand prize and all fly off together to europe where they manage to cause one stupid disaster after another of all the ridiculous unfunny money spinning sequels this one beats the lot harold ramis 1983 film was a below average misadventure in which the misfit family went on a nightmarish vacation`.

Sai positive dù đoạn đầu có stupid, ridiculous, unfunny và below average. Nhiều token kể cốt truyện, tên riêng và thuật ngữ sequels/misadventure tạo nhiễu. Từ phủ định sắc thái unfunny có thể hiếm hoặc embedding học chưa tốt; cần ablation/đổi câu để xác minh. Truncation làm mất các nhận xét awful/disastrous ở sau, nhưng đoạn đầu vốn đã có tín hiệu negative nên không thể quy toàn bộ lỗi cho truncation.

Top key nhận attention: cause (vị trí 26, 0.1640), off (vị trí 18, 0.1227), t (vị trí 5, 0.0558), harold (vị trí 45, 0.0327), lot (vị trí 44, 0.0304). Vị trí là 0-based sau tokenize. Các từ đáng kiểm tra còn trong cửa sổ: stupid, ridiculous, unfunny, below, average; bị mất/không nằm trong đoạn giữ: không có. Trong các từ đáng kiểm tra còn thấy, từ lọt top-5 keys: không có. Do attention này trung bình qua query/head, token quan trọng không lọt top-5 không có nghĩa model bỏ qua; token lọt top-5 cũng không chứng minh nó gây ra prediction.

## Nhận xét và hướng cải thiện

Sáu ví dụ thể hiện contrast/ambiguous sentiment, phủ định và contraction, review dài/truncation, từ hiếm/tên riêng, thuật ngữ điện ảnh và noise sau tokenize. Mỗi yếu tố là một giả thuyết cần kiểm chứng, không tự xem là nguyên nhân của lỗi. Để thử: đánh giá riêng câu phủ định, giữ phần cuối review, tokenizer tốt hơn, tăng dữ liệu hoặc pretrained encoder; lựa chọn cấu hình dựa validation. Cần nhiều mẫu lỗi hơn để ước lượng tần suất các loại lỗi.

Không đồng nhất attention với explanation: trọng số còn đi cùng value vectors, output projection, residual, FFN, pooling và classifier. Attention visualization chỉ cho phân phối nội bộ; muốn kết luận nhân quả cần can thiệp có kiểm soát, ví dụ thay/cắt token và so sánh xác suất, đồng thời lưu ý distribution shift.
